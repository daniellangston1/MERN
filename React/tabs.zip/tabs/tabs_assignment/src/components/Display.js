import React from 'react'


const Display = (props)=>{


    const {tabText} = props;

    return(
        <div>
            {tabText}
        </div>
    )
}


export default Display;